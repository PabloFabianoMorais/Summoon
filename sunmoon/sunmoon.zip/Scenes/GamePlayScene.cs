using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using sunmoon.Core.Management;
using sunmoon.Core.Factory;
using Microsoft.Xna.Framework.Input;

namespace sunmoon.Scenes
{
    public class GamePlayScene : Scene
    {

        public override void LoadContent(ContentManager content)
        {
            GameObjectManager = new GameObjectManager();
            

            GameObjectManager.Add(GameObjectFactory.Create("Player"));
        }

        public override void UnloadContent()
        {
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            GameObjectManager.Draw(spriteBatch);
        }

        public override void Update(GameTime gameTime)
        {
            GameObjectManager.Update(gameTime);
        }
    }
}
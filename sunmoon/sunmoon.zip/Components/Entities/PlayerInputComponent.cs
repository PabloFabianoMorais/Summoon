using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using sunmoon.Core;
using sunmoon.Core.ECS;

namespace sunmoon.Components
{
    // Gerencia os inpus que controlam o player
    public class PlayerInputComponent : Component, IUpdatableComponent
    {
        private MovementComponent _movementComponent;

        public override void Initialize()
        {
            _movementComponent = GameObject.GetComponent<MovementComponent>();
            base.Initialize();
        }

        public void Update(GameTime gameTime)
        {
            KeyboardState keyboardState = Keyboard.GetState();

            // Movemento WASD
            if (keyboardState.IsKeyDown(Keys.D))
                _movementComponent.Velocity.X += _movementComponent.MovementSpeed;
            if (keyboardState.IsKeyDown(Keys.A))
                _movementComponent.Velocity.X -= _movementComponent.MovementSpeed;
            if (keyboardState.IsKeyDown(Keys.S))
                _movementComponent.Velocity.Y += _movementComponent.MovementSpeed;
            if (keyboardState.IsKeyDown(Keys.W))
                _movementComponent.Velocity.Y -= _movementComponent.MovementSpeed;
        }
    }
}

using sunmoon.Core.ECS;

namespace sunmoon.Components
{
    public class EntityComponent : Component
    {
        public long Id { get; set; }
    }
}